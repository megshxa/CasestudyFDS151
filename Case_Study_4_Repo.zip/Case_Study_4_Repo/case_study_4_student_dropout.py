#!/usr/bin/env python
# coding: utf-8

# # Case Study 4: Predicting Student Dropout and Academic Success
# **Name:** Megha Annavarapu | **Roll No:** 160124733151 | **Section:** CSE 3 | **Subject:** Fundamentals of Data Science
# 
# **Goal:** analyse student records and build a multiclass logistic regression model that predicts whether a student's outcome is *Dropout*, *Enrolled* or *Graduate*, using only information available early (at enrolment and after the first semester).

# ## Part A: Data understanding and preprocessing
# ### A1-A2. Load the data and inspect it
# The file is semicolon-separated, so `sep=';'` is used. Column names contain a hidden BOM character and a stray tab, which are cleaned so later code does not break.

# In[1]:


from IPython.display import display
import pandas as pd, numpy as np, json, warnings, os
import matplotlib.pyplot as plt, seaborn as sns
from scipy import stats
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, ConfusionMatrixDisplay,
                             classification_report, precision_recall_fscore_support)
warnings.filterwarnings('ignore'); sns.set_theme(style='whitegrid'); RS=42
os.makedirs('figures',exist_ok=True); R={}   # R collects numbers for the report

df=pd.read_csv('Studentdata.csv',sep=';',encoding='utf-8-sig')
df.columns=[c.strip() for c in df.columns]
df=df.rename(columns={'Nacionality':'Nationality'})
print(df.head())
print('Rows, columns:',df.shape)
print(df.dtypes.value_counts()); print(df.dtypes.to_string())


# **Observation:** 4,424 students and 37 columns (36 predictors + `Target`). Almost every column is stored as a number, but many of these numbers are only *codes* for categories (for example `Course = 9500`), so the data type alone does not tell us whether a column is truly numeric. This is handled in A4.

# ### A3. Target variable vs predictors

# In[2]:


target='Target'; predictors=[c for c in df.columns if c!=target]
print('Target:',target,'| classes:',sorted(df[target].unique()))
print('Number of predictors:',len(predictors))


# **Target:** `Target` (Dropout / Enrolled / Graduate). All other 36 columns are predictor candidates. Note that the target is the status at the *end* of the normal course duration, so columns recorded *after* the prediction moment (second-semester results) would leak the outcome; this is addressed in Part D.

# ### A4. Categorising attributes by what the codes actually mean

# In[3]:


nominal=['Marital status','Application mode','Course','Previous qualification','Nationality',
         "Mother's qualification","Father's qualification","Mother's occupation","Father's occupation"]
binary=['Daytime/evening attendance','Displaced','Educational special needs','Debtor',
        'Tuition fees up to date','Gender','Scholarship holder','International']
ordinal=['Application order']
numerical=[c for c in predictors if c not in nominal+binary+ordinal]
for n,l in [('Nominal categorical (codes, no order)',nominal),('Binary (0/1)',binary),('Ordinal',ordinal),('Numerical',numerical)]:
    print(f'\n{n} [{len(l)}]:',l)


# **Reasoning:** `Marital status`, `Application mode`, `Course`, `Previous qualification`, `Nationality` and the parents' qualification/occupation columns are integer *labels*; code 12 is not "twice" code 6, so treating them as numbers would be wrong and they need one-hot encoding. Eight columns are yes/no flags. `Application order` (0 = first choice ... 9 = last choice) is ordinal. The rest (grades, unit counts, age, macro-economic indicators) are genuinely numeric.

# ### A5. Missing values, duplicates and unusual values

# In[4]:


print('Missing values (total):',int(df.isna().sum().sum()))
print('Duplicate rows:',int(df.duplicated().sum()))
print('\nUnusual-value checks')
print('Age at enrollment: min',df['Age at enrollment'].min(),'max',df['Age at enrollment'].max())
print('Admission grade range:',df['Admission grade'].min(),'-',df['Admission grade'].max())
print('Students with 1st-sem grade = 0:',int((df['Curricular units 1st sem (grade)']==0).sum()),
      '(',round((df['Curricular units 1st sem (grade)']==0).mean()*100,1),'%)')
print('  of which enrolled in 0 units:',int(((df['Curricular units 1st sem (grade)']==0)&(df['Curricular units 1st sem (enrolled)']==0)).sum()))
print('Students with 1st-sem enrolled = 0:',int((df['Curricular units 1st sem (enrolled)']==0).sum()))
print('Age > 40:',int((df['Age at enrollment']>40).sum()))
print('Approved > enrolled (1st sem):',int((df['Curricular units 1st sem (approved)']>df['Curricular units 1st sem (enrolled)']).sum()))
R['n_rows'],R['n_cols']=df.shape; R['missing']=int(df.isna().sum().sum()); R['dups']=int(df.duplicated().sum())
R['zero_grade']=int((df['Curricular units 1st sem (grade)']==0).sum())
R['zero_enrolled']=int((df['Curricular units 1st sem (enrolled)']==0).sum())
R['age_gt40']=int((df['Age at enrollment']>40).sum())
R['approved_gt_enrolled']=int((df['Curricular units 1st sem (approved)']>df['Curricular units 1st sem (enrolled)']).sum())


# **Observation:** there are no missing values and no duplicate rows. Unusual values exist but are *real, not errors*: a first-semester grade of 0 usually means the student had no graded units (e.g. never evaluated or enrolled in 0 units), and ages above 40 are mature students. These are kept; zero grades are handled carefully in the hypothesis test (Part C).

# ### A6. Distributions of selected numerical attributes (Histograms)

# In[5]:


fig,ax=plt.subplots(1,3,figsize=(16,4.2))
for a,(c,col) in zip(ax,[('Age at enrollment','#2c6fb0'),('Admission grade','#e08a1e'),('Curricular units 1st sem (grade)','#3a9d5d')]):
    sns.histplot(df[c],bins=30,color=col,ax=a,kde=True)
    a.axvline(df[c].mean(),color='k',ls='--',lw=1,label=f'Mean {df[c].mean():.1f}')
    a.axvline(df[c].median(),color='r',ls=':',lw=1.3,label=f'Median {df[c].median():.1f}')
    a.set_title(f'Distribution of {c}'); a.set_xlabel(c); a.set_ylabel('Number of students'); a.legend()
plt.tight_layout(); plt.savefig('figures/fig1_hist.png',dpi=150); plt.show()
for c in ['Age at enrollment','Admission grade','Curricular units 1st sem (grade)']:
    print(f'{c}: skew={df[c].skew():.2f}')
    R['skew_'+c]=round(df[c].skew(),2)


# **Interpretation:** *Age at enrollment* is strongly right-skewed (most students enrol at 18-20, with a long tail of mature students). *Admission grade* is roughly bell-shaped around its mean. *First-semester grade* is bimodal: a spike at 0 (students with no graded units) and a main group between roughly 11 and 14. The spike at 0 is the reason a plain mean would be misleading.

# ### A7. Preprocessing needed before modelling
# 1. **Drop post-prediction columns** (all second-semester variables) to avoid data leakage; the aim is an *early* prediction.
# 2. **One-hot encode** the nominal code columns so the model does not read an order into them.
# 3. **Standardise** numeric columns (`StandardScaler`), because logistic regression is sensitive to scale and standardised coefficients become comparable.
# 4. **Stratified train/test split** to keep the class proportions in both sets (the classes are imbalanced).
# 5. Fit all transformers **only on the training set** (inside a `Pipeline`) to avoid test-set leakage.
# 6. No imputation or de-duplication is needed (no missing values or duplicates).

# ## Part B: Exploratory data analysis and statistics
# ### B8-B9. Target class distribution

# In[6]:


vc=df[target].value_counts(); pc=(vc/len(df)*100).round(2)
tab=pd.DataFrame({'Students':vc,'Percentage (%)':pc}); display(tab)
R['target_counts']=vc.to_dict(); R['target_pct']=pc.to_dict()
order=['Dropout','Enrolled','Graduate']; pal={'Dropout':'#c0392b','Enrolled':'#e0a31e','Graduate':'#2c8c5a'}
plt.figure(figsize=(6.5,4.2))
ax=sns.barplot(x=vc.reindex(order).index,y=vc.reindex(order).values,palette=[pal[o] for o in order])
for i,o in enumerate(order): ax.text(i,vc[o]+20,f'{vc[o]} ({pc[o]}%)',ha='center')
plt.title('Distribution of Student Outcomes'); plt.xlabel('Outcome (Target)'); plt.ylabel('Number of students'); plt.ylim(0,2500)
plt.tight_layout(); plt.savefig('figures/fig2_target.png',dpi=150); plt.show()


# **Interpretation:** Graduates are the largest group (about half), Dropouts are about a third and Enrolled students are only about 18%. The classes are therefore **imbalanced**, which will matter when judging the classifier: a model can look good on accuracy simply by favouring Graduate.

# ### B10. Descriptive statistics of selected numerical variables

# In[7]:


sel=['Age at enrollment','Admission grade','Previous qualification (grade)','Curricular units 1st sem (approved)','Curricular units 1st sem (grade)']
d=df[sel].describe().T; d['skew']=df[sel].skew(); display(d.round(2))
R['desc']=d.round(2).reset_index().rename(columns={'index':'Variable'}).to_dict('records')


# **Interpretation:** the mean age (about 23) is above the median (20), confirming right skew. Admission grade averages about 127 on a 0-200 scale with moderate spread. First-semester grade has a mean (about 10.6) pulled down by the zeros, so it is lower than the typical grade of students who were actually graded.

# ### B11. Do admission grades differ across outcomes? (Box plot)

# In[8]:


print(df.groupby(target)['Admission grade'].agg(['count','mean','median','std']).round(2))
R['adm']=df.groupby(target)['Admission grade'].agg(['mean','median','std']).round(2).reset_index().to_dict('records')
plt.figure(figsize=(7,4.5))
sns.boxplot(data=df,x=target,y='Admission grade',order=order,palette=pal)
plt.title('Admission Grade by Student Outcome'); plt.xlabel('Outcome'); plt.ylabel('Admission grade (0-200)')
plt.tight_layout(); plt.savefig('figures/fig3_adm_box.png',dpi=150); plt.show()


# **Interpretation:** Graduates have a slightly higher median admission grade than Dropouts, but the boxes overlap heavily. Admission grade is therefore only a **weak** separator of outcomes: many strong-entry students drop out and many weaker-entry students graduate.

# ### B12. First-semester performance vs outcome

# In[9]:


fig,ax=plt.subplots(1,2,figsize=(13,4.5))
sns.boxplot(data=df,x=target,y='Curricular units 1st sem (grade)',order=order,palette=pal,ax=ax[0])
ax[0].set_title('1st-Semester Grade by Outcome'); ax[0].set_xlabel('Outcome'); ax[0].set_ylabel('1st-semester average grade (0-20)')
df['sem1_approval_rate']=(df['Curricular units 1st sem (approved)']/df['Curricular units 1st sem (enrolled)'].replace(0,np.nan))
sns.boxplot(data=df,x=target,y='Curricular units 1st sem (approved)',order=order,palette=pal,ax=ax[1])
ax[1].set_title('Units Approved in 1st Semester by Outcome'); ax[1].set_xlabel('Outcome'); ax[1].set_ylabel('Units approved')
plt.tight_layout(); plt.savefig('figures/fig4_sem1.png',dpi=150); plt.show()
g=df.groupby(target)[['Curricular units 1st sem (grade)','Curricular units 1st sem (approved)']].mean().round(2); display(g)
R['sem1']=g.reset_index().to_dict('records')
print('Share with 1st-sem grade 0:'); z=df.assign(z=df['Curricular units 1st sem (grade)']==0).groupby(target)['z'].mean().mul(100).round(1); print(z)
R['zero_share']=z.to_dict()
df=df.drop(columns='sem1_approval_rate')


# **Interpretation:** first-semester performance separates the outcomes far more clearly than admission grade. Graduates have the highest grades and approve the most units; Dropouts have much lower grades and approve few units, and many Dropouts have a grade of exactly 0 (no graded units). Enrolled students lie in between. This is the strongest early-warning signal in the data.

# ### B13. Age at enrollment and outcome

# In[10]:


df['Age group']=pd.cut(df['Age at enrollment'],[0,19,22,29,100],labels=['<=19','20-22','23-29','30+'])
ct=pd.crosstab(df['Age group'],df[target],normalize='index').mul(100).round(1)[order]; display(ct)
R['age_ct']=ct.reset_index().astype({'Age group':str}).to_dict('records')
ct.plot(kind='bar',stacked=True,color=[pal[o] for o in order],figsize=(7,4.5))
plt.title('Outcome Distribution by Age Group at Enrollment'); plt.xlabel('Age group at enrollment (years)'); plt.ylabel('Share of students (%)'); plt.xticks(rotation=0); plt.legend(title='Outcome',loc='upper right',bbox_to_anchor=(1.28,1))
plt.tight_layout(); plt.savefig('figures/fig5_age.png',dpi=150); plt.show()
print(df.groupby(target)['Age at enrollment'].median())


# **Interpretation:** the Dropout share rises steadily with age: students aged 30+ drop out much more often than those aged 19 or younger. This is an *association*; older students often work or have family duties, but the data cannot show that age causes dropout.

# ### B14. Findings communicated (summary)
# 1. The classes are imbalanced (Graduate ~50%, Dropout ~32%, Enrolled ~18%).
# 2. First-semester grade and approved units strongly differ by outcome, whereas admission grade differs only slightly.
# 3. Dropout share is higher for older enrolment ages.

# ## Part C: Hypothesis testing
# ### C15. Hypotheses
# **Research question:** do first-semester grades differ across the three outcome groups?
# 
# - **H0:** the distribution of first-semester grade is the same for Dropout, Enrolled and Graduate students.
# - **H1:** at least one outcome group has a different distribution of first-semester grade.
# 
# ### C16-C17. Choice of test and assumptions
# One-way ANOVA would compare three means, but it assumes (i) independent observations, (ii) approximately normal values within each group and (iii) equal variances. We check (ii) and (iii) below. Because of the zero spike the distribution is clearly non-normal, so the **Kruskal-Wallis H test** (rank-based, no normality assumption) is selected. ANOVA is also reported as a cross-check.

# In[11]:


col='Curricular units 1st sem (grade)'
groups=[df.loc[df[target]==o,col] for o in order]
# assumption checks
for o,g in zip(order,groups):
    s=stats.skew(g); print(f'{o}: n={len(g)}, skew={s:.2f}, Shapiro p (sample of 500)={stats.shapiro(g.sample(500,random_state=RS))[1]:.2e}')
lev=stats.levene(*groups); print('Levene (equal variances): stat=%.2f p=%.2e'%(lev.statistic,lev.pvalue))


# **Assumption check:** the Shapiro-Wilk tests reject normality in every group and Levene's test rejects equal variances, so ANOVA's assumptions are *not* reasonable here. Observations are one row per student, so independence is plausible. Kruskal-Wallis is the appropriate choice.

# ### C18-C19. Run the test (alpha = 0.05) and measure the effect size

# In[12]:


H,p=stats.kruskal(*groups); n=len(df); k=3
eps2=(H-k+1)/(n-k)          # epsilon-squared effect size for Kruskal-Wallis
F,pF=stats.f_oneway(*groups)
print(f'Kruskal-Wallis: H = {H:.2f}, df = 2, p = {p:.3e}')
print(f'Effect size epsilon^2 = {eps2:.3f}')
print(f'ANOVA (cross-check): F = {F:.2f}, p = {pF:.3e}')
# post-hoc pairwise Mann-Whitney with Bonferroni
import itertools
post={}
for a,b in itertools.combinations(order,2):
    u,pp=stats.mannwhitneyu(df.loc[df[target]==a,col],df.loc[df[target]==b,col]); pb=min(pp*3,1)
    rbc=1-2*u/(len(df[df[target]==a])*len(df[df[target]==b]))
    post[f'{a} vs {b}']=(round(pb,4),round(rbc,3)); print(f'{a} vs {b}: Bonferroni p = {pb:.2e}, rank-biserial r = {rbc:.2f}')
# sensitivity: only students with a graded first semester
nz=df[df[col]>0]; H2,p2=stats.kruskal(*[nz.loc[nz[target]==o,col] for o in order])
eps2b=(H2-2)/(len(nz)-3); print(f'Sensitivity (grade>0 only, n={len(nz)}): H = {H2:.2f}, p = {p2:.2e}, epsilon^2 = {eps2b:.3f}')
print('Median grade (>0 only):',nz.groupby(target)[col].median().round(2).to_dict())
R['kw']=dict(H=round(H,2),p=float(p),eps2=round(eps2,3),F=round(F,2),pF=float(pF),
             lev=round(lev.statistic,2),post={k:list(v) for k,v in post.items()},
             H2=round(H2,2),p2=float(p2),eps2b=round(eps2b,3),n_nz=len(nz),
             med_nz={k:float(v) for k,v in nz.groupby(target)[col].median().round(2).items()})


# **Conclusion:** the p-value is far below 0.05, so we **reject H0**: first-semester grades differ across outcome groups. The effect size is large (epsilon-squared = 0.25; roughly 0.08 is medium and 0.26 large by common rules of thumb), and the result remains significant, with a medium effect (epsilon-squared = 0.13), when students with a grade of 0 are excluded, so it is not only caused by the zero spike. With 4,424 students even tiny differences would be significant, which is why the effect size and the box plot matter: here the difference is both statistically significant **and** practically important (mean first-semester grade is 12.6 for Graduates vs 7.3 for Dropouts; among graded students the medians differ by about 1 point, a smaller but still real gap). Pairwise tests show that all three pairs differ, with the Dropout-Graduate gap the largest. This shows association, not causation.

# ## Part D: Classification model
# ### D20-D21. Predictors, target and split
# **Prediction moment:** the target is the status at the *end* of the course, so the model should use only information known early. We use enrolment-time information plus **first-semester** results (an end-of-semester-1 early-warning model) and **exclude all second-semester variables**, which would arrive too late and leak the outcome. A stratified 80/20 split keeps class proportions the same in train and test, and `random_state=42` makes it reproducible.

# In[13]:


sem2=[c for c in predictors if '2nd sem' in c]; print('Excluded (second semester):',len(sem2),'columns')
X_cols=[c for c in predictors if c not in sem2]
X=df[X_cols]; y=df[target]
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=0.2,stratify=y,random_state=RS)
print('Train:',Xtr.shape,'Test:',Xte.shape)
print('Train %:',(ytr.value_counts(normalize=True)*100).round(1).to_dict())
print('Test  %:',(yte.value_counts(normalize=True)*100).round(1).to_dict())
R['n_train'],R['n_test'],R['n_feat_raw']=len(Xtr),len(Xte),len(X_cols)


# ### D22. Encoding and scaling
# Nominal columns are one-hot encoded (`handle_unknown='ignore'` so rare categories in the test set do not crash). Numerical and ordinal columns are standardised. Binary columns are passed through unchanged. Everything is fitted on the training data only.

# In[14]:


nom=[c for c in nominal if c in X_cols]; binc=[c for c in binary if c in X_cols]
num=[c for c in X_cols if c not in nom+binc]
def make_pre(nom,binc,num):
    return ColumnTransformer([('cat',OneHotEncoder(handle_unknown='ignore'),nom),
                              ('num',StandardScaler(),num),('bin','passthrough',binc)])
pre=make_pre(nom,binc,num)
print('Nominal:',len(nom),'| Numeric/ordinal:',len(num),'| Binary:',len(binc))


# ### D23-D24. Multiclass logistic regression and predictions
# `LogisticRegression` (multinomial, lbfgs, L2) is trained. A second version with `class_weight='balanced'` is also fitted to study the effect of class imbalance (D29).

# In[15]:


model=Pipeline([('pre',pre),('lr',LogisticRegression(max_iter=3000,random_state=RS))]).fit(Xtr,ytr)
model_bal=Pipeline([('pre',make_pre(nom,binc,num)),('lr',LogisticRegression(max_iter=3000,class_weight='balanced',random_state=RS))]).fit(Xtr,ytr)
pred=model.predict(Xte); pred_bal=model_bal.predict(Xte)
print('Sample predictions:',list(pred[:8]))


# ### D25. Confusion matrix

# In[16]:


labs=['Dropout','Enrolled','Graduate']
cm=confusion_matrix(yte,pred,labels=labs); R['cm']=cm.tolist()
fig,ax=plt.subplots(1,2,figsize=(12,4.6))
ConfusionMatrixDisplay(cm,display_labels=labs).plot(ax=ax[0],cmap='Blues',colorbar=False)
ax[0].set_title('Confusion Matrix: Logistic Regression (counts)'); ax[0].set_xlabel('Predicted outcome'); ax[0].set_ylabel('True outcome')
cmn=confusion_matrix(yte,pred,labels=labs,normalize='true')
ConfusionMatrixDisplay(cmn.round(2),display_labels=labs).plot(ax=ax[1],cmap='Blues',colorbar=False)
ax[1].set_title('Confusion Matrix (row-normalised: recall per class)'); ax[1].set_xlabel('Predicted outcome'); ax[1].set_ylabel('True outcome')
plt.tight_layout(); plt.savefig('figures/fig6_cm.png',dpi=150); plt.show(); print(cm)


# ### D26-D27. Accuracy, precision, recall, F1 and macro averages

# In[17]:


def table(yt,yp):
    p,r,f,s=precision_recall_fscore_support(yt,yp,labels=labs,zero_division=0)
    t=pd.DataFrame({'Precision':p,'Recall':r,'F1-score':f,'Support':s},index=labs)
    mp,mr,mf,_=precision_recall_fscore_support(yt,yp,average='macro',zero_division=0)
    t.loc['Macro avg']=[mp,mr,mf,s.sum()]
    wp,wr,wf,_=precision_recall_fscore_support(yt,yp,average='weighted',zero_division=0)
    t.loc['Weighted avg']=[wp,wr,wf,s.sum()]
    return t.round(3)
t1=table(yte,pred); t2=table(yte,pred_bal)
acc1,acc2=accuracy_score(yte,pred),accuracy_score(yte,pred_bal)
print('Standard model, accuracy = %.3f'%acc1); display(t1)
print('Class-weighted model, accuracy = %.3f'%acc2); display(t2)
R['acc'],R['acc_bal']=round(acc1,3),round(acc2,3)
R['t1']=t1.reset_index().rename(columns={'index':'Class'}).to_dict('records')
R['t2']=t2.reset_index().rename(columns={'index':'Class'}).to_dict('records')
R['cm_bal']=confusion_matrix(yte,pred_bal,labels=labs).tolist()


# ### D28-D29. Per-class performance and class imbalance
# **Per class:** the model is good at identifying Graduates and Dropouts, but it is clearly weakest on the **Enrolled** class, which has low recall and F1: Enrolled students sit between the other two groups (similar grades) and are the smallest class, so many are predicted as Graduate or Dropout.
# 
# **Imbalance:** overall accuracy hides this weakness, because the large Graduate class dominates it. Macro-averaged metrics give every class equal weight and are therefore lower than accuracy. Using `class_weight='balanced'` raises Enrolled recall at the cost of lower overall accuracy and Graduate precision; which version is better depends on whether missing at-risk students or raising false alarms is costlier.

# ## Part E: Interpretation and recommendations
# ### E30-E31. Coefficients (standardised features)
# Because numerical features are standardised and binary features are 0/1, coefficients are comparable in size. A positive coefficient for the Dropout class means a higher predicted log-odds of Dropout (relative to the other classes) when the feature increases, holding other features fixed.

# In[18]:


names=model.named_steps['pre'].get_feature_names_out(); lr=model.named_steps['lr']
coef=pd.DataFrame(lr.coef_.T,index=names,columns=lr.classes_)
coef.index=[n.split('__',1)[1] for n in coef.index]
# readable view: numeric + binary features only (one-hot course/occupation codes are shown separately)
nb=coef[[ (n in num) or (n in binc) for n in coef.index]]
top=nb['Dropout'].reindex(nb['Dropout'].abs().sort_values(ascending=False).index).head(10)
print('Top numeric/binary drivers of the Dropout class:'); display(top.round(3).to_frame('Dropout coef'))
R['coef_top']=top.round(3).to_dict()
gr=nb['Graduate'].reindex(nb['Graduate'].abs().sort_values(ascending=False).index).head(8); R['coef_grad']=gr.round(3).to_dict()
catc=coef[[ (n not in num) and (n not in binc) for n in coef.index]]
cc=catc['Dropout'].reindex(catc['Dropout'].abs().sort_values(ascending=False).index).head(6); R['coef_cat']=cc.round(3).to_dict()
print('Largest one-hot (category) effects on Dropout:'); display(cc.round(3).to_frame('Dropout coef'))
plt.figure(figsize=(8,4.8)); t=top.sort_values()
plt.barh(t.index,t.values,color=['#c0392b' if v>0 else '#2c8c5a' for v in t.values])
plt.title('Strongest Logistic-Regression Coefficients for the Dropout Class'); plt.xlabel('Coefficient (standardised; positive = higher Dropout odds)'); plt.ylabel('Feature')
plt.tight_layout(); plt.savefig('figures/fig7_coef.png',dpi=150); plt.show()


# **Interpretation:** features that describe first-semester academic progress (units approved, grades, units enrolled and evaluated) have the largest coefficients; more approved units and higher grades are associated with *lower* Dropout odds. Financial indicators such as tuition fees being up to date and scholarship holding point the same way (up-to-date fees and scholarships are associated with lower Dropout odds), while being a debtor is associated with higher odds. Enrolling in many units while approving few (positive coefficient on units enrolled once approved units are held fixed) is also associated with higher Dropout odds. These are **associations that help prediction, not causes**; for example a debtor flag may reflect financial stress, but the data cannot show that debt itself causes dropout.

# ### E32. Limitations
# 1. **Early-prediction scope:** the model uses first-semester data only, so it cannot see later changes in a student's situation.
# 2. **Class imbalance and the Enrolled class:** performance on Enrolled students is poor, so the model should not be used to decide about them.
# 3. **Association, not causation:** coefficients can be confounded, and one-hot course/occupation codes have small groups with unstable estimates.
# 4. **Linear model assumption:** logistic regression cannot capture interactions or non-linear effects, so some predictive signal is lost.
# 5. **Single institution and single split:** results come from one institution and one 80/20 split; they may not transfer and have uncertainty.
# 
# ### E33. Recommended interventions (evidence-based, to investigate)
# 1. **First-semester early-warning programme:** the strongest signal is low units approved and low grades in semester 1 (Figures 4, 7), so trigger tutoring or advising at the end of semester 1 for students with few approved units.
# 2. **Financial-support check-ins:** up-to-date tuition fees and scholarships are associated with lower Dropout odds, so flag students with overdue fees for support (payment plans, scholarship advice).
# 3. **Support for mature students:** the Dropout share grows with age at enrolment (Figure 5), so evaluate flexible timetables, part-time options and peer groups for older students.
# 4. **Review the Enrolled group manually:** since the model is unreliable for them, use advisor review rather than automatic flags.
# 
# ### E34. Responsible use
# Use predictions only as a prompt for **supportive** contact, never for penalties, admission or funding decisions. Keep a human advisor in the loop and explain flags to students. Do not use gender, nationality, marital status or other demographic attributes as grounds for action, and audit error rates across groups (for example by gender or age) before deployment. Re-train and re-check regularly, and keep the risk score confidential so students are not labelled.

# ## Conclusion
# The dataset has 4,424 students with imbalanced outcomes. First-semester performance is the clearest marker of outcome (Kruskal-Wallis, p < 0.05 with a large effect), while admission grade is only a weak signal. A multiclass logistic regression using enrolment and first-semester data classifies Dropout and Graduate students reasonably but is weak on Enrolled students, so accuracy alone is misleading and macro-averaged metrics should be reported. The model is best used as a supportive early-warning aid, not a decision tool.

# In[19]:


json.dump(R,open('results.json','w'),default=str,indent=1); print('saved')

