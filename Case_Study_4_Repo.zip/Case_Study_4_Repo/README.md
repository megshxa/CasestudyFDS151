# Case Study 4: Predicting Student Dropout and Academic Success Using Data Science

**Name:** Megha Annavarapu
**Roll No:** 160124733151
**Section:** CSE 3 (Batch 1)
**Subject:** Fundamentals of Data Science
**Year:** 2026

## Problem statement
A higher-education institution wants to understand the factors associated with student dropout and academic success, and to predict whether a student's outcome is **Dropout**, **Enrolled** or **Graduate**, so that support for at-risk students can be planned.

## Repository contents
| File | Description |
|---|---|
| `Case_Study_4_Student_Dropout.ipynb` | Jupyter Notebook with the full executable code, outputs and visualisations |
| `case_study_4_student_dropout.py` | The same code as a Python script |
| `Studentdata.csv` | Dataset (4,424 students, 37 columns, semicolon-separated) |
| `Case_Study_4_Report.pdf` | Report: problem statement, methodology, statistical findings, model evaluation, conclusion |
| `figures/` | All graphs produced by the notebook |
| `requirements.txt` | Python libraries needed |

## How to run
```bash
pip install -r requirements.txt
jupyter notebook Case_Study_4_Student_Dropout.ipynb     # Run All
# or
python case_study_4_student_dropout.py
```
Keep `Studentdata.csv` in the same folder as the notebook. Random seed is 42, so results are reproducible.

## Method summary
1. **Data understanding (Part A):** loaded the data with Pandas, checked shape, types, missing values (0), duplicates (0) and unusual values; categorised attributes as nominal, binary, ordinal or numerical by what their codes mean.
2. **EDA (Part B):** class distribution, descriptive statistics, admission grade, first-semester performance and age versus outcome.
3. **Hypothesis test (Part C):** Kruskal-Wallis test on first-semester grade across the three outcomes (ANOVA assumptions failed), alpha = 0.05, with effect size and post-hoc tests.
4. **Model (Part D):** stratified 80/20 split, one-hot encoding and standardisation in a Pipeline, multinomial logistic regression, plus a class-weighted version. Second-semester variables were excluded to avoid data leakage (early prediction).
5. **Interpretation (Part E):** coefficients, limitations, recommendations and responsible use.

## Key results
- Outcomes: Graduate 49.9%, Dropout 32.1%, Enrolled 18.0% (imbalanced).
- Kruskal-Wallis: H = 1094.19, p < 0.001, epsilon-squared = 0.25 (large effect).
- Logistic regression: accuracy 0.746, macro precision 0.68, macro recall 0.66, macro F1 0.66.
- Per-class F1: Graduate 0.83, Dropout 0.77, Enrolled 0.39 (weakest).

## Required outputs (in `figures/` and the report)
- Target-class distribution bar chart (`fig2_target.png`)
- Histograms of numerical attributes (`fig1_hist.png`)
- Box plot of admission grade by outcome (`fig3_adm_box.png`)
- First-semester grade comparison by outcome (`fig4_sem1.png`)
- Age versus outcome (`fig5_age.png`)
- Confusion matrix (`fig6_cm.png`)
- Coefficient plot (`fig7_coef.png`)
- Classification performance table: in the notebook and report (Section 6.2)

## Recommendations
1. First-semester early-warning programme for students with few approved units.
2. Financial-support check-ins for students with overdue fees.
3. Flexible support for mature students.
4. Advisor review for the Enrolled group.

## Note
Findings describe associations, not causes. The model should be used only to offer supportive contact, never to penalise or label students.
